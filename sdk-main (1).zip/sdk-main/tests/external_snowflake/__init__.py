"""SDK Snowflake sample tests."""
