"""SDK external system tests."""
