"""SDK core tests."""
