singer\_sdk.authenticators.APIKeyAuthenticator
=============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: APIKeyAuthenticator
    :members:
