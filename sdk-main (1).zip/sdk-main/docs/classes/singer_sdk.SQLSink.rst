singer\_sdk.SQLSink
======================

.. currentmodule:: singer_sdk

.. autoclass:: SQLSink
    :members:
