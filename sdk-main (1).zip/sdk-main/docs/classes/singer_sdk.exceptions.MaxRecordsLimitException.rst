singer\_sdk.exceptions.MaxRecordsLimitException
==============================================

.. currentmodule:: singer_sdk.exceptions

.. autoexception:: MaxRecordsLimitException