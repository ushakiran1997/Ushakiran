singer\_sdk.RecordSink
==================

.. currentmodule:: singer_sdk

.. autoclass:: RecordSink
    :members:
