singer\_sdk.authenticators.SimpleAuthenticator
==============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: SimpleAuthenticator
    :members:
