singer\_sdk.exceptions.TapStreamConnectionFailure
=================================================

.. currentmodule:: singer_sdk.exceptions

.. autoexception:: TapStreamConnectionFailure