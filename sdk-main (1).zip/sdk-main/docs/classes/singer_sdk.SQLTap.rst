singer\_sdk.SQLTap
===============

.. currentmodule:: singer_sdk

.. autoclass:: SQLTap
    :members:
