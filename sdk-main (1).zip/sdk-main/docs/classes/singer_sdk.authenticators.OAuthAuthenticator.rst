singer\_sdk.authenticators.OAuthAuthenticator
=============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: OAuthAuthenticator
    :members:
