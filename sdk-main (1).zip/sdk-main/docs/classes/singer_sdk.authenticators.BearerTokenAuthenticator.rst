singer\_sdk.authenticators.BearerTokenAuthenticator
=============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: BearerTokenAuthenticator
    :members:
