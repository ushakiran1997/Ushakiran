singer\_sdk.BatchSink
==================

.. currentmodule:: singer_sdk

.. autoclass:: BatchSink
    :members:
