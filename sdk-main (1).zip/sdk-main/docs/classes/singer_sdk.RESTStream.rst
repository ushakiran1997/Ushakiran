singer\_sdk.RESTStream
======================

.. currentmodule:: singer_sdk

.. autoclass:: RESTStream
    :members:
