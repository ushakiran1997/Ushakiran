singer\_sdk.GraphQLStream
=========================

.. currentmodule:: singer_sdk

.. autoclass:: GraphQLStream
    :members:
