singer\_sdk.authenticators.BasicAuthenticator
=============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: BasicAuthenticator
    :members:
