singer\_sdk.SQLStream
======================

.. currentmodule:: singer_sdk

.. autoclass:: SQLStream
    :members:
