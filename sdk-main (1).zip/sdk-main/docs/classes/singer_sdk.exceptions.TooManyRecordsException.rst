singer\_sdk.exceptions.TooManyRecordsException
==============================================

.. currentmodule:: singer_sdk.exceptions

.. autoexception:: TooManyRecordsException