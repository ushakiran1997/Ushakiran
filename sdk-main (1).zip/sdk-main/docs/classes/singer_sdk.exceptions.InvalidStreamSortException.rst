singer\_sdk.exceptions.InvalidStreamSortException
==============================================

.. currentmodule:: singer_sdk.exceptions

.. autoexception:: InvalidStreamSortException