singer\_sdk.Sink
==================

.. currentmodule:: singer_sdk

.. autoclass:: Sink
    :members:
