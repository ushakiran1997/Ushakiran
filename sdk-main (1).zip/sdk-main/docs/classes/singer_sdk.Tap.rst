singer\_sdk.Tap
===============

.. currentmodule:: singer_sdk

.. autoclass:: Tap
    :members:
