singer\_sdk.SQLTarget
===============

.. currentmodule:: singer_sdk

.. autoclass:: SQLTarget
    :members:
