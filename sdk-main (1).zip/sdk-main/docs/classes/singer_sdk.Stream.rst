singer\_sdk.Stream
==================

.. currentmodule:: singer_sdk

.. autoclass:: Stream
    :members:
