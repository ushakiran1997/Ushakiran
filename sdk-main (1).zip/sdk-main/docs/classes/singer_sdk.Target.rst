singer\_sdk.Target
===============

.. currentmodule:: singer_sdk

.. autoclass:: Target
    :members:
