singer\_sdk.exceptions.FatalAPIError
==============================================

.. currentmodule:: singer_sdk.exceptions

.. autoexception:: FatalAPIError