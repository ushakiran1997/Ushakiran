singer\_sdk.InlineMapper
========================

.. currentmodule:: singer_sdk

.. autoclass:: InlineMapper
    :members:
