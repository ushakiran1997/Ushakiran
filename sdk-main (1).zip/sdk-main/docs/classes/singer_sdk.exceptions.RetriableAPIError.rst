singer\_sdk.exceptions.RetriableAPIError
==============================================

.. currentmodule:: singer_sdk.exceptions

.. autoexception:: RetriableAPIError