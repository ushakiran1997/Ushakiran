singer\_sdk.SQLConnector
======================

.. currentmodule:: singer_sdk

.. autoclass:: SQLConnector
    :members:
