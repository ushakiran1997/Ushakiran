# [SDK Implementation Details](./README.md) - Catalog Metadata

_**Note:**: The SDK does not yet generate metadata as a part of catalog discovery output.
This work is [tracked here](https://gitlab.com/meltano/sdk/-/issues/91) for future
development._

## See Also

- [Singer Spec: Metadata](https://hub.meltano.com/singer/spec#metadata)
