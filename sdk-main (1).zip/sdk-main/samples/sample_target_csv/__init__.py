"""Module test for target-csv functionality."""
