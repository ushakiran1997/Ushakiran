"""Gitlab API Sample."""
