"""Stream maps transformer."""
