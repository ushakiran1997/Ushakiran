"""Google Analytics sample."""
